package br.edu.infnet.auxiliar;

public class Constante {

    public static final String[] PRODUTOS = {"INFORMATICA", "PAPELARIA", "MANUTENCAO"};

    public static final String TFUNCIONARIO = "arquivos/tfuncionario.txt";

    public static final String TSOLICITACAO = "arquivos/tsolicitacao.txt";

    public static final String TINFORMATICA = "arquivos/tinformatica.txt";

    public static final String TMANUTENCAO = "arquivos/tmanutencao.txt";

    public static final String TPAPELARIA = "arquivos/tpapelaria.txt";

    public static final String TSETOR = "arquivos/tsetor.txt";

}
